const express = require('express');
const { register, login } = require('../controllers/authController');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const User = require('../models/User');

// Auth routes
router.post('/register', register);
router.post('/login', login);

// ✅ Get all students for faculty dropdown
router.get('/students', protect, async (req, res) => {
  try {
    const students = await User.find({ role: 'student' }).select('name _id');
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
